public class grua extends Vehiculo {
    public grua(String matricula, String color, String marca) {
        super(matricula, color, marca);
    }
}

