public class moto extends Vehiculo {
    public moto(String matricula, String color, String marca) {
        super(matricula, color, marca);
    }
    
    // Métodos específicos para motos
}

