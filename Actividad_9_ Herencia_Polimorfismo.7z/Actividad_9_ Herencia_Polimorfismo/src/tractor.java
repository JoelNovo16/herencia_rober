public class tractor extends Vehiculo { 
    public tractor(String matricula, String color, String marca) {
        super(matricula, color, marca);
    }
    
    // Métodos específicos para tractores
}
