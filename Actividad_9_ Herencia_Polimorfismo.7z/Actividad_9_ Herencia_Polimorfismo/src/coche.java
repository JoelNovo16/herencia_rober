public class coche extends Vehiculo {
    public coche(String matricula, String color, String marca) {
        super(matricula, color, marca);
    }
    
    // Métodos específicos para coches
}

